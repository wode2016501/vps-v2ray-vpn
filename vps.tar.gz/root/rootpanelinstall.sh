#!/bin/sh
#

echo
echo "=== Recipe Default started at $(date) ==="
echo

if [ -f /etc/redhat-release ]; then
        OSNAME=centos
else
        OSNAME=debian
fi
if [ "${OSNAME}" = "centos" ]; then
	echo 'HISTTIMEFORMAT="%d/%m/%y %T "' > /etc/profile.d/history.sh
	echo "ip_resolve=4" >> /etc/yum.conf
	if [[ `cat /etc/redhat-release |egrep -i 'release (7|8|9)'` ]];then
		sed -i -r "s/#Port 22/Port 3333/" /etc/ssh/sshd_config
		sed -i -r "s/installonly_limit.*/installonly_limit=2/" /etc/yum.conf
		firewall-cmd --zone=public --permanent --add-port=3333/tcp
		systemctl stop firewalld
		systemctl mask firewalld
		systemctl restart sshd
	else
		sed -i -r "s/#Port 22/Port 3333/" /etc/ssh/sshd_config
		iptables -F
		iptables-save > /etc/sysconfig/iptables
		/etc/init.d/sshd restart
	fi
else
	sed -i -r "s/.*Port 22/Port 3333/" /etc/ssh/sshd_config
	sed -i -r "s/.*PermitRootLogin.*/PermitRootLogin yes/" /etc/ssh/sshd_config
	echo 'HISTTIMEFORMAT="%d/%m/%y %T "' > /etc/profile.d/history.sh
	echo 'Acquire::ForceIPv4 "true";' | tee /etc/apt/apt.conf.d/99force-ipv4
	service ssh restart
fi
echo "ROOTPANELOK"	
